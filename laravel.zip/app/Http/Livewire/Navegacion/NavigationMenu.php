<?php

namespace App\Http\Livewire\Navegacion;

use Livewire\Component;

class NavigationMenu extends Component
{
    public function render()
    {
        return view('livewire.navegacion.navigation-menu');
    }
}
