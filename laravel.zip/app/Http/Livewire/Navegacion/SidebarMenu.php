<?php

namespace App\Http\Livewire\Navegacion;

use Livewire\Component;

class SidebarMenu extends Component
{
    public function render()
    {
        return view('livewire.navegacion.sidebar-menu');
    }
}
